import os

from flask import Blueprint, render_template
from flask_login import login_required

from config import role_required, Log

security_bp = Blueprint('security', __name__, template_folder='templates')

@security_bp.route('/security')
@login_required
@role_required('sec_admin')
def security():
    logs = Log.query.all()

    # Path to the security log file
    log_file_path = os.path.join(os.getcwd(), 'security.log')

    # Read the last 10 lines of the log file
    log_entries = []
    if os.path.exists(log_file_path):
        with open(log_file_path, 'r') as file:
            log_entries = file.readlines()[-10:]  # Get the last 10 lines
            log_entries.reverse()  # Reverse the order to make the most recent first

    return render_template('security/security.html', logs=logs, log_entries=log_entries)


