from cryptography.fernet import Fernet
from flask import Blueprint, render_template, flash, url_for, redirect, request
from flask_login import current_user, login_required

from config import db, Post, role_required, logger, generate_key
from posts.forms import PostForm
from sqlalchemy import desc
posts_bp = Blueprint('posts', __name__, template_folder='templates')

@posts_bp.route('/create', methods=('GET', 'POST'))
@login_required
@role_required('end_user')
def create():
    form = PostForm()  # Initialize the form for creating a new post

    if form.validate_on_submit():
        user_key = generate_key(current_user.password, current_user.salt)  # Generate encryption key using user's data
        cipher = Fernet(user_key)  # Create a Fernet cipher for encryption

        # Encrypt the post title and body
        encrypted_title = cipher.encrypt(form.title.data.encode())
        encrypted_body = cipher.encrypt(form.body.data.encode())

        # Create a new Post object with encrypted data
        new_post = Post(
            encrypted_title=encrypted_title,
            encrypted_body=encrypted_body,
            user_id=current_user.id
        )

        # Save the post to the database
        db.session.add(new_post)
        db.session.commit()

        flash('Post created', category='success')  # Flash success message
        logger.info(f"Post Creation [Email={current_user.email}, Post ID={new_post.id}, IP={request.remote_addr}]")
        return redirect(url_for('posts.posts'))  # Redirect to the list of posts

    return render_template('posts/create.html', form=form)  # Render the form if no data is submitted

@posts_bp.route('/posts')
@login_required
@role_required('end_user')
def posts():
    all_posts = Post.query.order_by(desc('id')).all()  # Retrieve all posts in descending order of creation

    for post in all_posts:
        try:
            user_key = generate_key(post.user.password, post.user.salt)  # Generate decryption key
            cipher = Fernet(user_key)

            # Decrypt and display the title and body
            post.title = cipher.decrypt(post.encrypted_title).decode()
            post.body = cipher.decrypt(post.encrypted_body).decode()
        except Exception:
            flash(f"Could not decrypt post ID {post.id}.", "danger")  # Display error if decryption fails

    return render_template('posts/posts.html', posts=all_posts)  # Render posts in a template


@posts_bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
@role_required('end_user')
def update(id):
    post_to_update = Post.query.filter_by(id=id).first()  # Fetch the post by ID

    if not post_to_update or post_to_update.user_id != current_user.id:
        flash("You can only update your own posts!", "danger")  # Ensure only the author can edit
        return redirect(url_for('posts.posts'))

    form = PostForm()
    user_key = generate_key(current_user.password, current_user.salt)  # Generate decryption key
    cipher = Fernet(user_key)

    if form.validate_on_submit():
        post_to_update.encrypted_title = cipher.encrypt(form.title.data.encode())  # Encrypt updated title
        post_to_update.encrypted_body = cipher.encrypt(form.body.data.encode())  # Encrypt updated body

        db.session.commit()  # Save changes to the database

        logger.info(f"Post Update [Email={current_user.email}, Post ID={post_to_update.id}]")
        flash('Post updated', category='success')
        return redirect(url_for('posts.posts'))

    # Pre-fill the form with decrypted data
    form.title.data = cipher.decrypt(post_to_update.encrypted_title).decode()
    form.body.data = cipher.decrypt(post_to_update.encrypted_body).decode()

    return render_template('posts/update.html', form=form)

@posts_bp.route('/<int:id>/delete')
@login_required
@role_required('end_user')
def delete(id):
    post_to_delete = Post.query.filter_by(id=id).first()  # Fetch the post by ID

    if not post_to_delete or post_to_delete.user_id != current_user.id:
        flash("You can only delete your own posts!", "danger")  # Ensure only the author can delete
        return redirect(url_for('posts.posts'))

    db.session.delete(post_to_delete)  # Delete the post from the database
    db.session.commit()

    logger.info(f"Post Deletion [Email={current_user.email}, Post ID={post_to_delete.id}]")
    flash('Post deleted', category='success')
    return redirect(url_for('posts.posts'))