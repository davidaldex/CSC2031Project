import re

from flask_wtf import FlaskForm, RecaptchaField
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, ValidationError, Email, Regexp

# Form for user registration
class RegistrationForm(FlaskForm):
    # Email field with validators to ensure the input is not empty and is a valid email address
    email = StringField('Email', validators=[
        DataRequired(),  # Ensures the field is not empty
        Email(message="Enter a valid email address.")  # Validates email format
    ])

    # First Name field with validators for required input and allowed characters
    firstname = StringField('First Name', validators=[
        DataRequired(),  # Ensures the field is not empty
        Regexp(r'^[a-zA-Z- ]+$', message="First name must only contain letters or hyphens.")
        # Restricts to letters, hyphens, and spaces
    ])

    # Last Name field with similar validations as the First Name field
    lastname = StringField('Last Name', validators=[
        DataRequired(),
        Regexp(r'^[a-zA-Z- ]+$', message="Last name must only contain letters or hyphens.")
    ])

    # Phone field with a custom regex to validate UK landline numbers with hyphen formatting
    phone = StringField('Phone', validators=[
        DataRequired(),
        Regexp(
            r'^02\d-\d{8}|011\d-\d{7}|01\d1-\d{7}|01\d{3}-\d{5,6}$',
            message="Phone number must be a valid UK landline with a hyphen (-)."
        )
    ])

    # Password and confirmation fields to ensure proper input and matching
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired()])

    submit = SubmitField('Register')

    # Custom validator for password strength
    def validate_password(self, field):
        password = field.data
        # Check password length
        if len(password) < 8 or len(password) > 15:
            raise ValidationError("Password must be between 8 and 15 characters long.")
        # Check for at least one uppercase letter
        if not re.search(r'[A-Z]', password):
            raise ValidationError("Password must contain at least one uppercase letter.")
        # Check for at least one lowercase letter
        if not re.search(r'[a-z]', password):
            raise ValidationError("Password must contain at least one lowercase letter.")
        # Check for at least one digit
        if not re.search(r'[0-9]', password):
            raise ValidationError("Password must contain at least one digit.")
        # Check for at least one special character
        if not re.search(r'\W', password):  # \W matches any non-word character (special character)
            raise ValidationError("Password must contain at least one special character.")

    # Custom validator to ensure password confirmation matches the password
    def validate_confirm_password(self, field):
        if field.data != self.password.data:
            raise ValidationError("Passwords must match.")

    # Custom validator for First Name field to remove whitespace and check for invalid formatting
    def validate_firstname(self, field):
        field.data = field.data.strip()  # Remove leading/trailing spaces
        if not field.data:  # Ensure the field is not empty
            raise ValidationError("First name cannot be empty or only spaces.")
        if '  ' in field.data:  # Disallow consecutive spaces
            raise ValidationError("First name cannot contain consecutive spaces.")

    # Custom validator for Last Name field with similar logic to First Name
    def validate_lastname(self, field):
        field.data = field.data.strip()  # Remove leading/trailing spaces
        if not field.data:
            raise ValidationError("Last name cannot be empty or only spaces.")
        if '  ' in field.data:
            raise ValidationError("Last name cannot contain consecutive spaces.")

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    recaptcha = RecaptchaField()
    mfa_pin = StringField('MFA PIN', validators=[DataRequired()])
    submit = SubmitField('Login')