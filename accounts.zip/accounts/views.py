import pyotp
from cryptography.fernet import Fernet
from flask import Blueprint, render_template, flash, redirect, url_for, session, request
from flask_login import login_user, login_required, logout_user, current_user
from markupsafe import Markup

from accounts.forms import RegistrationForm, LoginForm
from config import User, db, limiter, Post, logger, generate_key

accounts_bp = Blueprint('accounts', __name__, template_folder='templates')

# Define a maximum number of login attempts
MAX_ATTEMPTS = 3

@accounts_bp.route('/registration', methods=['GET','POST'])
def registration():
    # Redirect to posts if the user is already logged in
    if current_user.is_authenticated:
        flash("You are already logged in!", "info")
        return redirect(url_for('posts.posts'))

    form = RegistrationForm()  # Initialize the registration form

    if form.validate_on_submit():
        # Check if the email is already registered
        if User.query.filter_by(email=form.email.data).first():
            flash('Email already exists', category="danger")
            return render_template('accounts/registration.html', form=form)

        # Create a new user with form data
        new_user = User(
            email=form.email.data,
            firstname=form.firstname.data,
            lastname=form.lastname.data,
            phone=form.phone.data,
            password=form.password.data,
            role='end_user'  # Default role is 'end_user'
        )

        # Add the new user to the database
        db.session.add(new_user)
        db.session.commit()

        # Log the registration event
        new_user.create_log()

        session['email'] = form.email.data  # Store the user's email in the session
        flash('Account created successfully! Set up MFA to proceed with login.', category='success')
        logger.info(f"User Registration [Email={new_user.email}, Role={new_user.role}, IP={request.remote_addr}]")

        # Redirect to MFA setup
        return redirect(url_for('accounts.mfa_setup',
            mfa_key=new_user.mfa_key,
            qr_code_uri=new_user.qr_code_uri,
            source='registration'
        ))

    # Render the registration form if the request is GET or the form is invalid
    return render_template('accounts/registration.html', form=form)

# Apply the rate limit of 20 calls per minute to the login view
@accounts_bp.route('/login', methods=['GET', 'POST'])
@limiter.limit("20 per minute")
def login():
    # Redirect if the user is already authenticated
    if current_user.is_authenticated:
        flash("You are already logged in!", "info")
        return redirect(url_for('posts.posts'))  # Redirect to the posts page

    # Initialize the attempts count in session if not present
    if 'attempts' not in session:
        session['attempts'] = 0

    form = LoginForm()

    # Check if form submission is valid
    if form.validate_on_submit():
        # Retrieve user based on form email
        user = User.query.filter_by(email=form.email.data).first()

        # Check if user exists and password matches
        if user and user.verify_password(form.password.data):
            # Check if MFA is required
            if user.mfa_enabled:
                # Verify the submitted MFA PIN
                mfa_pin = form.mfa_pin.data
                if not pyotp.TOTP(user.mfa_key).verify(mfa_pin):
                    # Increment attempts and flash error if MFA PIN is incorrect
                    session['attempts'] += 1
                    lock, remaining_attempts = handle_login_attempts(form.email.data, session['attempts'])
                    if lock:
                        return render_template('accounts/login.html', form=form, locked=True)
                    else:
                        flash(f"Invalid MFA PIN. {remaining_attempts} attempts remaining.", 'danger')
                        return redirect(url_for('accounts.login'))

            # Automatically enable MFA if PIN is verified during first MFA-enabled login
            elif not user.mfa_enabled and pyotp.TOTP(user.mfa_key).verify(form.mfa_pin.data):
                # Successful login: reset attempts and mark MFA as enabled if first login with MFA
                session['attempts'] = 0
                user.mfa_enabled = True
                db.session.commit()
                flash("Multi-Factor Authentication has been successfully enabled for your account.",
                      "success")
            # If MFA is not enabled and MFA pin does not match, redirect to MFA setup page
            else:
                session['email'] = form.email.data
                return redirect(url_for('accounts.mfa_setup',source='login'))

            # Log the user in and update the login log
            login_user(user)
            user.update_login_log(request.remote_addr)  # Update the login log with the user's IP address
            logger.info(
                f"User Login [Email={user.email}, Role={user.role}, IP={request.remote_addr}]")
            # Redirect to the appropriate page based on the user's role
            if user.role == 'end_user':
                flash("Login successful! Welcome back.", 'success')
                return redirect(url_for('posts.posts'))
            elif user.role == 'db_admin':
                flash("Login successful! Welcome back.", 'success')
                return redirect("https://127.0.0.1:5000/admin")  # Database Admin page
            elif user.role == 'sec_admin':
                flash("Login successful! Welcome back.", 'success')
                return redirect(url_for('security.security'))

        # Increment attempts and handle failed authentication
        else:
            session['attempts'] += 1
            lock, remaining_attempts = handle_login_attempts(form.email.data, session['attempts'])
            if lock:
                return render_template('accounts/login.html', form=form, locked=True)
            else:
                return redirect(url_for('accounts.login'))

    # Handle CAPTCHA or other form errors if not valid
    if 'recaptcha' in form.errors:
        flash("Please complete the CAPTCHA to proceed.", 'danger')

    # Render the login form for GET requests or if form is invalid
    return render_template('accounts/login.html', form=form)

@accounts_bp.route('/reset_attempts')
def reset_attempts():
    # Reset the login attempt count
    session['attempts'] = 0
    flash('Your account has been unlocked. Please try logging in again.', 'info')
    return redirect(url_for('accounts.login'))

@accounts_bp.route('/account')
@login_required  # This ensures only logged-in users can access the page
def account():
    user = User.query.get(current_user.id)  # Get the current user
    user_posts = Post.query.filter_by(user_id=current_user.id).all()  # Get the user's posts

    for post in user_posts:
        try:
            user_key = generate_key(post.user.password, post.user.salt)  # Generate the decryption key
            cipher = Fernet(user_key)
            post.title = cipher.decrypt(post.encrypted_title).decode()  # Decrypt the post title
            post.body = cipher.decrypt(post.encrypted_body).decode()  # Decrypt the post body
        except Exception:
            flash(f"Could not decrypt post ID {post.id}.", "danger")

    # Render the account page and pass the user data
    return render_template('accounts/account.html', user=user, posts=user_posts)

@accounts_bp.route('/mfa_setup')
def mfa_setup():
    source = request.args.get('source')  # Determine if the user came from login or registration
    user = User.query.filter_by(email=session['email']).first()  # Get the user from the session

    if not user:
        flash("Session expired or user not found. Please log in again.", "danger")
        return redirect(url_for('accounts.login'))

    # Generate the QR code URI for MFA setup
    qr_code_uri = str(pyotp.totp.TOTP(user.mfa_key).provisioning_uri(user.email, issuer_name="C3010220 Blog"))
    return render_template('accounts/mfa_setup.html', mfa_key=user.mfa_key, qr_code_uri=qr_code_uri,
                        source=source)

@accounts_bp.route('/logout')
@login_required
def logout():
    logout_user()

    flash('You have been logged out.', 'info')
    return redirect(url_for('accounts.login'))

# Helper function to handle login attempt increments and logging
def handle_login_attempts(form_email, session_attempts):
    remaining_attempts = MAX_ATTEMPTS - session_attempts
    if session_attempts >= MAX_ATTEMPTS:
        flash(Markup(f"Login failed. Too many attempts. <a href='{url_for('accounts.reset_attempts')}'>"
                     f"Click here to reset your attempts</a>."), 'danger')
        logger.error(
            f"Maximum Invalid Login Attempts [Email={form_email if form_email else 'Unknown'}, "
            f"Attempts={session_attempts}, IP={request.remote_addr}]"
        )
        return True, remaining_attempts  # Returning True to indicate a lock
    else:
        logger.warning(f"Invalid Login Attempt [Email={form_email}, "
                       f"Attempts={session_attempts}, IP={request.remote_addr}]")
        flash(f"Invalid email or password. {remaining_attempts} attempts remaining.", 'danger')
        return False, remaining_attempts